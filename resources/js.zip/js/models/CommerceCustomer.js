import Model from "@/models/Model";

export default class CommerceCustomer extends Model {}
