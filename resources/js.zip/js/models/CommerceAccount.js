import Model from "@/models/Model";

export default class CommerceAccount extends Model {}
