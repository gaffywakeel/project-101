import Model from "@/models/Model";

class PaymentAccount extends Model {}

export default PaymentAccount;
