export * from "./result500";
export {default} from "./result500";
