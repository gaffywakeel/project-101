export * from "./pageTabs";
export {default} from "./pageTabs";
