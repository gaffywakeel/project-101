export * from "./modalContent";
export {default} from "./modalContent";
