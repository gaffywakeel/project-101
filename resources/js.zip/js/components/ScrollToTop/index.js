export * from "./scrollToTop";
export {default} from "./scrollToTop";
