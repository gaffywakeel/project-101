export * from "./pageSlider";
export {default} from "./pageSlider";
