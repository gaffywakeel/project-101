export * from "./stepIcon";
export {default} from "./stepIcon";
