export const varHover = (scale) => ({
    hover: {scale: scale || 1.1}
});
