const Hidden = () => {
    return null;
};

export default Hidden;
