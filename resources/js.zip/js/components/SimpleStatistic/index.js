export * from "./simpleStatistic";
export {default} from "./simpleStatistic";
