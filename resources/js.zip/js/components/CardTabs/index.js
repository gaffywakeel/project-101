export * from "./cardTabs";
export {default} from "./cardTabs";
