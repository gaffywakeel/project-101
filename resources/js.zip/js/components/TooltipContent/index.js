export * from "./tooltipContent";
export {default} from "./tooltipContent";
