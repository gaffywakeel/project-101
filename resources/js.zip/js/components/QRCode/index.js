export * from "./qRCode";
export {default} from "./qRCode";
