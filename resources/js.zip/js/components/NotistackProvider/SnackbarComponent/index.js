export * from "./snackbarComponent";
export {default} from "./snackbarComponent";
