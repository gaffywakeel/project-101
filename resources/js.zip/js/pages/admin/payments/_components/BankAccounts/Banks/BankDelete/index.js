export * from "./bankDelete";
export {default} from "./bankDelete";
