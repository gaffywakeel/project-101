export * from "./uploadLogos";
export {default} from "./uploadLogos";
