export * from "./manageLocales";
export {default} from "./manageLocales";
