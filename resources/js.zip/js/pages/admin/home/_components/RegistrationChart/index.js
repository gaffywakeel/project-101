export * from "./registrationChart";
export {default} from "./registrationChart";
